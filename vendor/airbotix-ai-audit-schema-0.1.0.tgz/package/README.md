# @airbotix-ai/audit-schema

The cross-product **audit event contract** for the Airbotix AI platform — the single source of
truth for the wire shape, taxonomy, category/retention map, and redaction rules that
kids-opencode, platform-backend, teacher-console, and airbotix-app all agree on.

Implements [`audit-event-schema-prd.md` v0.2](https://github.com/Airbotix-AI/airbotix-ai/blob/main/docs/product/prd/audit-event-schema-prd.md).
**Zod schemas are the source of truth; TypeScript types are derived via `z.infer`** (D-AUD10).

## Install

```bash
npm i @airbotix-ai/audit-schema zod
```

`zod` is a peer dependency so the package shares the consumer's Zod instance (platform-backend
already runs `nestjs-zod` + `zod`, so ingest reuses these schemas directly — one fact source, no
DTO drift).

## Usage

### Runtime (ingest / validation)

```ts
import {
  AuditEventInputSchema,
  deriveCategory,
  defaultRetentionFor,
  scanForProhibitedContent,
} from "@airbotix-ai/audit-schema";

const input = AuditEventInputSchema.parse(req.body);          // reject malformed events
const violations = scanForProhibitedContent(input.payload);   // §3.7 negative validation at ingest
if (violations.length) reject(input.event_id, violations);

const category = deriveCategory(input.event_type);            // server-derived (§3.5)
const retention = defaultRetentionFor(input.event_type);      // provisional default
```

### Type-only (frontends)

```ts
import type { AuditEventRecord, AuditCategory } from "@airbotix-ai/audit-schema/types";
```

The `/types` subpath pulls **zero runtime** (no Zod bundle).

## Contents

| Export | PRD | What |
|---|---|---|
| `AuditEventInputSchema` | §3.1 | Wire shape emitters send (shipped flat contract + additive optional fields) |
| `AuditEventRecordSchema` | §3.2 | Read model consumers receive (input + server-set `id`/`received_at`/`category`/`retention`) |
| `KIDS_EVENT_TYPES`, `KidsAuditEventSchema` | §3.4/§3.6 | Frozen kids-pipeline taxonomy + discriminated union over events with live emitters |
| `EVENT_CATEGORY`, `PLATFORM_CATEGORY_PREFIXES`, `deriveCategory` | §3.5 | Server-side category derivation + `CATEGORY_RETENTION` defaults |
| `PROHIBITED_PATTERNS`, `scanForProhibitedContent` | §3.7 | Ingest negative-validation patterns (credentials / email / phone) |

## Versioning (PRD §4.2)

First publish `0.1.0`; consumers depend `^0.1.0`. During `0.x`: **minor = breaking, patch =
additive**. `1.0.0` aligns with `schema_version: "1"`; thereafter additive = minor,
rename/remove/requiredness change = major + a `schema_version` bump.

## Develop

```bash
npm install
npm test          # vitest
npm run typecheck # tsc --noEmit
npm run build     # tsup → dist/ (ESM + CJS + d.ts, with /types subpath)
```

## Scope notes

- **Payload shapes are published only for events with live emitters** (§3.6). "name frozen,
  payload pending" events validate against the base input schema and gain shapes via minor
  releases when their emitters land — no guessed shapes are frozen.
- Categories for kids events not covered by an explicit §3.5 ruling are derived from namespace
  semantics; `deriveCategoryDetailed` returns `matched: false` for names that fall back to the
  default so callers can log a warning.
